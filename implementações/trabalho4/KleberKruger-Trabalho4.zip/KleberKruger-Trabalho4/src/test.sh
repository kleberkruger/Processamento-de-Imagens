# baboon.png
python3 encoder.py ../in/baboon.png ../in/message.txt 0 ../out/baboon_0.png
python3 encoder.py ../in/baboon.png ../in/message.txt 1 ../out/baboon_1.png
python3 encoder.py ../in/baboon.png ../in/message.txt 2 ../out/baboon_2.png

python3 decoder.py ../out/baboon_0.png 0 ../out/messagem_baboon_0.txt
python3 decoder.py ../out/baboon_1.png 1 ../out/messagem_baboon_1.txt
python3 decoder.py ../out/baboon_2.png 2 ../out/messagem_baboon_2.txt


# monalisa.png
python3 encoder.py ../in/monalisa.png ../in/message.txt 0 ../out/monalisa_0.png
python3 encoder.py ../in/monalisa.png ../in/message.txt 1 ../out/monalisa_1.png
python3 encoder.py ../in/monalisa.png ../in/message.txt 2 ../out/monalisa_2.png

python3 decoder.py ../out/monalisa_0.png 0 ../out/messagem_monalisa_0.txt
python3 decoder.py ../out/monalisa_1.png 1 ../out/messagem_monalisa_1.txt
python3 decoder.py ../out/monalisa_2.png 2 ../out/messagem_monalisa_2.txt



# peppers.png
python3 encoder.py ../in/peppers.png ../in/message.txt 0 ../out/peppers_0.png
python3 encoder.py ../in/peppers.png ../in/message.txt 1 ../out/peppers_1.png
python3 encoder.py ../in/peppers.png ../in/message.txt 2 ../out/peppers_2.png

python3 decoder.py ../out/peppers_0.png 0 ../out/messagem_peppers_0.txt
python3 decoder.py ../out/peppers_1.png 1 ../out/messagem_peppers_1.txt
python3 decoder.py ../out/peppers_2.png 2 ../out/messagem_peppers_2.txt



# watch.png
python3 encoder.py ../in/watch.png ../in/message.txt 0 ../out/watch_0.png
python3 encoder.py ../in/watch.png ../in/message.txt 1 ../out/watch_1.png
python3 encoder.py ../in/watch.png ../in/message.txt 2 ../out/watch_2.png

python3 decoder.py ../out/watch_0.png 0 ../out/messagem_watch_0.txt
python3 decoder.py ../out/watch_1.png 1 ../out/messagem_watch_1.txt
python3 decoder.py ../out/watch_2.png 2 ../out/messagem_watch_2.txt
